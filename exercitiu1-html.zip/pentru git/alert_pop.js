function Show_Alert(Input_Id) {
    var My_Message = document.getElementById(Input_Id).value;

    if(My_Message==""){   
   
    alert('please add name change');}

    else {
        alert('hello sweet  '+My_Message);
    }

}